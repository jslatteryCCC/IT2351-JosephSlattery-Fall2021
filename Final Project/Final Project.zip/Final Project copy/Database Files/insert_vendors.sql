INSERT INTO vendors VALUES
(1,	'Van Rooy Coffee', '123 Van Rooy Way',	'Cleveland',	'OH',	'216-555-7894',	'vanrooy@yahoo.com'),
(2,	'Tommys Bakery',	'456 Detroit',	'Lakewood',	'OH',	'216-555-6454',	'bagels@tommys.com'),
(3,	'Dairymans',	'888 Dairyman St',	'Cleveland', 'OH', 	'216-555-8888',	'milk@dairyman.com'),
(4,	'Sugar & Such',	'771 Domino Blvd',	'Akron', 	'OH',	'330-555-8832',	'sugar@gmail.com'),
(5,	'Sysco',	'349 Sysco Rd', 'Cleveland', 'OH', '216-555-0009', 'paper@sysco.com');
