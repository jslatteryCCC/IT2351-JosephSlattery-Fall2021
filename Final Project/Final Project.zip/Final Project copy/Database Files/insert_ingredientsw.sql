INSERT INTO ingredients VALUES
(1,	1,	'coffee '),
(2,	2,	'bagels'),
(3,	4,	'syrups'),
(4,	3,	'half & half'),
(5,	5,	'cups');
