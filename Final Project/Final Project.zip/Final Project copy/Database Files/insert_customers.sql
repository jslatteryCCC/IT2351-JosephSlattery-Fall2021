INSERT INTO customers VALUES
(1 ,"IX Center", "123 IX Way", "Cleveland", "OH", "Olga Avasarala", "olga@yahoo.com", "216-555-1212"),
(2, "Moen", "456 Moen Blvd", "North Olmsted", "OH", "Larry Moen", "larry@moen.com", "440-555-7423"),
(3, "Hyland Software", "987 Hyland Way", "Westlake", "OH",	"Jacob Davis", "jacob@hyland.com", "440-555-8789"),
(4, "Cleveland Clinic", "789 Clinic Rd", "Cleveland", "OH", "Bill Higgins", "bill@clinic.com",	"216-555-3232"),
(5, "RS Tool & Die", "123 Puritas Ave", "Cleveland", "OH", "Rocco Sangiacomo", "rocco@rstool.com", "216-555-1245");
