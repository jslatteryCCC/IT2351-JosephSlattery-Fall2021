INSERT INTO products VALUES
(1,	1,	'drip coffee for 10'),
(2,	2,	'bagel service for 10'),
(3,	3,	'flavored coffee add on'),
(4,	4,	'creamer add on'),
(5,	5,	'togo add on');
